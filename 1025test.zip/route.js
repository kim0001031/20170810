express = require("express");
model = require("./models/dracenaApi");
receiveDP = require("./controllers/receiveDeriveryPlan")
plugin = require("./controllers/plugin");

app = express();
const port = 3000;

const wrap = fn => (...args) => fn(...args).catch(args[2]);
app.post('/init', wrap(async(req, res, next) => {
    
    plugin.read();
    //res.send("test"); 
}));

//configuration
const configurationPost = fn => (...args) => fn(...args).catch(args[2]);
app.post('/configuration', configurationPost(plugin.regConfiguration));

//configuration
const configurationGet = fn => (...args) => fn(...args).catch(args[2]);
app.get('/configuration', configurationGet(plugin.getConfiguration));

//plugin
const pluginGet = fn => (...args) => fn(...args).catch(args[2]);
app.get('/plugin', pluginGet(plugin.getPlugin));

app.listen(port, () => {
    console.log('Server running on port: ${port}');
})

