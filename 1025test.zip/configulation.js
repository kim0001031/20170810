const fs = require('fs');
const object = require('./util/object')
const objectInfo = require('../models/');
// 登録プラグインの保持
let registeredPlugin = {};

try{
    fs.readFile('./postGet.json', "utf-8", (err, data) =>{
        console.log(data);
        registeredPlugin = JSON.parse(data);
    });
}catch(error){
    throw error;
}

if(validationPlugin(registeredPlugin)){
    throw "file error";
}


module.exports = {
    // プラグインの登録
    async doPost(req, res, next) {
        try {
          console.dir(req.query);
          //バリデーションチェック
          if(validationConfig(req.query)){
            throw new Error();
          }
        } catch (e) {
          res.status(400).send('Invalid JSON string');
          return;
        }
        
        try{
          // 前回の定義内容の削除
          deleteObject(registeredPlugin);
          // 今回の定義内容での登録
          celeteObject(registeredPlugin);
        
          registeredPlugin = req.query;
        } catch (e) {
          res.statsu(500).send('Invalid Data NG');
          return;
        }
        
        res.status(200).send("Success");
    },

    // 登録プラグインの出力
    async doGet(req, res, next)  {
        // fileJson[0].test = "sample2";
        if(!Object.keys(registeredPlugin).length){
            res.status(404).send('Not Found');
            return;
        }
        res.status(200).send(JSON.stringify(registeredPlugin));
    },
}

function validationPlugin(pluginFile){
    //check plugin
    return true;
}

function validationConfig(checkPlugin){
  //check plugin
  return false;
}

function deleteObject(registeredPlugin){
    //check plugin

    return;
}
  
function createObject(registeredPlugin){
    //check plugin

    //truck
    //get truck
    let truckArray = getTruckArray(registeredPlugin);
    for(const oid of truckArray){
        //mversion, oid,  group,  plugin , stage
        object.create(objectInfo.getMversion(), oid ,"truck",0);
        pluginList = objectInfo.getPluginList("truck");
        for(const plugin of pluginList){
            //mversion, oid,  watchingStates , handler
            object.addHandler(objectInfo.getMversion(), oid ,plugin.wachingStates,plugin.name)
        }
    }
    //area
    //mversion, oid,  group,  plugin , stage
    object.create(objectInfo.getMversion(), oid ,"area",0);

    pluginList = objectInfo.getPluginList("area");
    for(const plugin of pluginList){
      //mversion, oid,  watchingStates , handler
      object.addHandler(objectInfo.getMversion(), oid ,plugin.wachingStates,plugin.name)
    }

    //basekpi
    for(const oid of truckArray){
      //mversion, oid,  group,  plugin , stage
      let oidBase = "base" + oid;
      object.create(objectInfo.getMversion(), oidBase ,"basekpi",1);

      pluginList = objectInfo.getPluginList("truck");
      for(const plugin of pluginList){
        //mversion, oid,  watchingStates , handler
        wachingStates = getWachingState(plugin.name);
        object.addHandler(objectInfo.getMversion(), oidBase ,wachingStates,plugin.name)
      }
    }
  
    //businesskpi
    let businessArray = getbusinessArray(registeredPlugin);
    for(const oidObj of businessArray){
        //mversion, oid,  group,  plugin , stage
        object.create(objectInfo.getMversion(), oidObj.oid ,"business",oidObj.stage);
        pluginList = objectInfo.getPluginList("truck");
        for(const plugin of pluginList){
            //mversion, oid,  watchingStates , handler
            object.addHandler(objectInfo.getMversion(), oid ,plugin.wachingStates,plugin.name)
        }
    }
    //評価
    let effectiveArray = getEffectiveArray(registeredPlugin);
    for(const oidObj of effectiveArray){
        //mversion, oid,  group,  plugin , stage
        object.create(objectInfo.getMversion(), oidObj.oid ,"business",oidObj.stage);
        pluginList = objectInfo.getPluginList("truck");
        for(const plugin of pluginList){
            //mversion, oid,  watchingStates , handler
            object.addHandler(objectInfo.getMversion(), oid ,plugin.wachingStates,plugin.name)
        }
    }
    return;
}


function getTruckArray(registeredPlugin){
    let truckArray = [];
    for(const plugin of registeredPlugin){
        switch(plugin.group){
            case "truck":
                break;
            case "area":
                break;
            case "basekpi":
                truckArray = getSourceArray(plugin.group.oidList);
                break;
            default:
                break;
        }
    }
    return truckArray;
}

function getSourceArray(array){
    let result = [];
    for(const data of array){
        result.push(data.source);
    }
    return result;
}