const fs = require('fs');
const object = require('./util/object')

// プラグイン管理ファイルの保持
let pluginFile = {};

try{
    fs.readFile('./file.json', "utf-8", (err, data) =>{
        console.log(data);
        pluginFile = JSON.parse(data);
    });
}catch(error){
    throw error;
}

if(validationPlugin(pluginFile)){
    throw "file error";
}

// 登録プラグインの保持
let registeredPlugin = {};

module.exports = {
    // プラグインの登録
    async regConfiguration(req, res, next) {
        try {
          console.dir(req.query);
          //バリデーションチェック
          if(validationConfig(req.query)){
            throw new Error();
          }
        } catch (e) {
          res.status(400).send('Invalid JSON string');
          return;
        }
        
        try{
          // 前回の定義内容の削除
          deleteObject();
          // 今回の定義内容での登録

        
          registeredPlugin = req.query;
        } catch (e) {
          res.statsu(500).send('Invalid Data NG');
          return;
        }
        
        res.status(200).send("Success");
    },

    // 登録プラグインの出力
    async getConfiguration(req, res, next)  {
        // fileJson[0].test = "sample2";
        if(!Object.keys(registeredPlugin).length){
            res.status(404).send('Not Found');
            return;
        }
        res.status(200).send(JSON.stringify(registeredPlugin));
    },

    // 登録プラグインの出力
    async getPlugin(req, res, next)  {
        // fileJson[0].test = "sample2";
        if(!Object.keys(pluginFile).length){
            res.status(404).send('Not Found');
            return;
        }
        res.status(200).send(JSON.stringify(pluginFile));
    }
}

function validationPlugin(pluginFile){
    //check plugin
    return true;
}

function validationConfig(checkPlugin){
  //check plugin
  return false;
}

function deleteObject(){
    //check plugin

    return;
}
  
function celeteObject(){
    //check plugin

    return;
}
  