$.jCanvas.defaults.fromCenter = false;
$.jCanvas.defaults.layer = true;


//状態保持
let statusObj = []; //{"canvas":canvasData, "name":name, "flag":false})
let clickFlag = false;//false:なし、true:選択済み
let clickObj = {};
function clickStatus(name){
	console.log("clickObj");
	console.log(clickObj);

	//canvasの配列を繰り返す
	for(let i=0;i<statusObj.length;i++){

		if(statusObj[i].name == name){
			if(clickObj.hasOwnProperty("name")){
				if(clickObj.name == name){
					console.log("同じものをクリックした");
				}else{
					drawLine2(clickObj,statusObj[i]);
				}
				clearCycle(clickObj);
				clickObj = {};
			}else{
				clickObj = statusObj[i];
				updateCycle(clickObj);
			}
		}
	}
}



function drawCycle(xsize, ysize,name) {
	let canvasData = $('canvas');
	canvasData.drawArc({
		layer: true,
		fillStyle: '#fff',
		strokeStyle: '#333',
		strokeWidth: 2,
		x: xsize, y: ysize,
		radius: 50,
		click: function(layer) {
			clickStatus(name);
		}
	});

	canvasData.drawText({
		fillStyle: '#9cf',
		strokeStyle: '#25a',
		strokeWidth: 2,
		x: xsize+10, y: ysize+40,
		fontSize: 20,
		fontFamily: 'Verdana, sans-serif',
		text: name
	});
	statusObj.push({"canvas":canvasData, "name":name, "flag":false,"x":xsize,"y":ysize});
	return canvasData;
}

function updateCycle(canvasObject) {
	console.log("update:"+canvasObject.name);
	let canvasData = canvasObject.canvas;
	canvasData.drawArc({
		layer: true,
		strokeStyle: '#c33',
		strokeWidth: 5,
		x: canvasObject.x, y: canvasObject.y,
		radius: 50,
		click: function(layer) {
			clickStatus(canvasObject.name);
		}
	});
}

function clearCycle(canvasObject) {
	let canvasData = canvasObject.canvas;
	canvasData.drawArc({
		layer: true,
		fillStyle: '#fff',
		strokeStyle: '#333',
		strokeWidth: 2,
		x: canvasObject.x, y: canvasObject.y,
		radius: 50,
		click: function(layer) {
			clickStatus(canvasObject.name);
		}
	});
	canvasData.drawText({
		fillStyle: '#9cf',
		strokeStyle: '#25a',
		strokeWidth: 2,
		x: canvasObject.x+10, y: canvasObject.y+40,
		fontSize: 20,
		fontFamily: 'Verdana, sans-serif',
		text: canvasObject.name
	});
}

function drawLine(x1,y1,x2,y2){
	let canvasData = $('canvas');
	canvasData.drawLine({
	  strokeStyle: '#000',
	  strokeWidth: 5,
	  rounded: true,
	  startArrow: false,
	  endArrow: true,
	  arrowRadius: 15,
	  arrowAngle: 90,
	  x1: x1+3, y1: y1,
	  x2: x2-7, y2: y2
	});
	return canvasData;
}

function drawLine2(obj1,obj2){
	let canvasData = $('canvas');
	console.log("drawLine2 start")
	canvasData.drawLine({
	  strokeStyle: '#000',
	  strokeWidth: 5,
	  rounded: true,
	  startArrow: false,
	  endArrow: true,
	  arrowRadius: 15,
	  arrowAngle: 90,
	  x1: obj1.x+103, y1: obj1.y+50,
	  x2: obj2.x-7, y2: obj2.y+50
	});
	return canvasData;
}


let cyc1 = drawCycle(100,100,"object1");
let cyc2 = drawCycle(300,100,"object2");
let cyc3 = drawCycle(500,100,"object3");
//drawLine(400,150,500,150);

