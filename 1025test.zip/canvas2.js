$.jCanvas.defaults.fromCenter = false;
$.jCanvas.defaults.layer = true;


//状態保持
let statusObj = []; //{"canvas":canvasData, "name":name, "flag":false})
let clickFlag = false;//false:なし、true:選択済み
let oneClick = {};
function clickStatus(name){
	let retObj = {};
	console.log("oneClick");
	console.log(oneClick);
	for(let i=0;i<statusObj.length;i++){
		if(statusObj[i].name == name){
			if(oneClick.hasOwnProperty("name")){
				if(oneClick.name == statusObj[i].name){
					console.log("同じものをクリックした");
				}else{
					drawLine2(oneClick,statusObj[i]);
				}
				console.log(statusObj[i]);
				oneClick = {};
			}else{
				oneClick = statusObj[i];
			}
			if(statusObj[i].flag){//選択あり
				
				statusObj[i].flag = false;
			}else{
				statusObj[i].flag = true;
				console.log(statusObj[i]);
			}
		}
	}
}

function drawCycle(xsize, ysize,name) {
	let canvasData = $('canvas');
	canvasData.drawArc({
		layer: true,
		fillStyle: '#fff',
		strokeStyle: '#333',
		x: xsize, y: ysize,
		radius: 50,
		click: function(layer) {
			let flag = clickStatus(name);
			if(flag){
				canvasData.animateLayer(layer, {
				fillStyle: '#c33'//赤
				}, 500);
			}else{
				canvasData.animateLayer(layer, {
				fillStyle: '#fff'//白
				}, 500);
			}
		}
	});

	canvasData.drawText({
		fillStyle: '#9cf',
		strokeStyle: '#25a',
		strokeWidth: 2,
		x: xsize+10, y: ysize+40,
		fontSize: 20,
		fontFamily: 'Verdana, sans-serif',
		text: name
	});
	statusObj.push({"canvas":canvasData, "name":name, "flag":false,"x":xsize,"y":ysize});
	return canvasData;
}

function drawLine(x1,y1,x2,y2){
	let canvasData = $('canvas');
	canvasData.drawLine({
	  strokeStyle: '#000',
	  strokeWidth: 5,
	  rounded: true,
	  startArrow: false,
	  endArrow: true,
	  arrowRadius: 15,
	  arrowAngle: 90,
	  x1: x1+3, y1: y1,
	  x2: x2-7, y2: y2
	});
	return canvasData;
}

function drawLine2(obj1,obj2){
	let canvasData = $('canvas');
	console.log("drawLine2 start")
	canvasData.drawLine({
	  strokeStyle: '#000',
	  strokeWidth: 5,
	  rounded: true,
	  startArrow: false,
	  endArrow: true,
	  arrowRadius: 15,
	  arrowAngle: 90,
	  x1: obj1.x+103, y1: obj1.y+50,
	  x2: obj2.x-7, y2: obj2.y+50
	});
	return canvasData;
}


let cyc1 = drawCycle(100,100,"cyc1");
let cyc2 = drawCycle(300,100,"cyc2");
let cyc3 = drawCycle(500,100,"cyc3");
//drawLine(400,150,500,150);

