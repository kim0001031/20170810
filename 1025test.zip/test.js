const stripe = require('stripe')();

// stripe.customers.create({
//   email: 'customer@example2.com',
// })
//   .then(customer => console.log(customer.id))
//   .catch(error => console.error(error));

// stripe.charges.create({
//     amount: 150,
//     currency: "jpy",
//     description: "test charge",
//     customer: "cus_IgDBo2oH21I96K"
//   })
//   .then(result => console.log(result))
//   .catch(error => console.error(error));

// plan = stripe.plans.create({
//     currency: 'jpy',
//     interval: 'month', //#year, month, week, day
//     product: 'prod_IgD0my4KEGSr5q', //#Product IDを指定
//     nickname: '毎月基本プラン',
//     amount: 980
//     })
//     .then(result => console.log(result))
//     .catch(error => console.error(error));

// stripe.subscriptions.create({
//     customer: "cus_IgDA6RH8xiZEZS",
//     trial_end: new Date("2021-02-01T00:00:00").getTime() / 1000,
//     plan: "plan_IgTvdgX5yJJ9kd"
//     })
//      .then(result => console.log(result))
//      .catch(error => console.error(error));

stripe.accounts.create({
        type: 'custom',
        country: 'US',
        email: 'testMail@example.com',
        capabilities: {
            card_payments: {requested: true},
            transfers: {requested: true},
      },
    })
      .then(result => console.log(result))
      .catch(error => console.error(error));

// stripe.accounts.del(
//     'acct_1I6dgn2RJaw7vk09'
//   )       
//   .then(result => console.log(result))
//   .catch(error => console.error(error));